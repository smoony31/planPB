import { defineStudio } from "../../src/tenant/schema";

// Всё, что отличает студию, лежит в этом файле и в папке photos/ рядом с ним.
export default defineStudio({
  slug: "detail-lab",
  name: "Detail Lab",
  tagline: "Детейлинг-студия: мойка, химчистка, полировка и керамика",
  address: "ул. Примерная, 12",
  phone: "+7 900 000-00-00",
  timezone: "Europe/Moscow",
  hours: { open: "09:00", close: "19:00" },
  daysOff: [0],
  prepMinutes: 30,
  cancelHours: 24,
  boxes: ["Бокс 1", "Бокс 2"],
  services: [
    { name: "Комплексная мойка", price: 1500, durationMin: 60 },
    { name: "Химчистка салона", price: 3500, durationMin: 120 },
    { name: "Полировка кузова", price: 8000, durationMin: 240 },
    { name: "Керамическое покрытие", price: 15000, durationMin: 720 },
  ],
  cards: [
    { title: "Гарантия", text: "Даём гарантию на все виды работ." },
    { title: "Материалы", text: "Работаем только с проверенной профессиональной химией." },
    { title: "Сроки", text: "Называем точное время готовности при записи." },
  ],
  works: [
    { file: "photos/work-1.jpg", caption: "Полировка кузова" },
    { file: "photos/work-2.jpg", caption: "Химчистка салона" },
    { file: "photos/work-3.jpg", caption: "Керамическое покрытие" },
  ],
  hero: "photos/hero.jpg",
  icon: "photos/icon.png",
  accent: "#4690FF",
});
