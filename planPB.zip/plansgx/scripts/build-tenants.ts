// Перед сборкой: для каждой студии кладёт фото, иконки и манифест установки в public/s/<slug>/
import { copyFileSync, mkdirSync, writeFileSync, rmSync } from "node:fs";
import { basename, join } from "node:path";
import sharp from "sharp";
import { ROOT, listTenants, loadTenant, tenantsDir } from "./lib.ts";

rmSync(join(ROOT, "public/s"), { recursive: true, force: true });
for (const slug of listTenants()) {
  const t = await loadTenant(slug);
  const out = join(ROOT, "public/s", slug);
  mkdirSync(join(out, "img"), { recursive: true });
  mkdirSync(join(out, "icons"), { recursive: true });
  for (const f of [t.hero, t.logo, ...t.works.map((w) => w.file)].filter(Boolean) as string[])
    copyFileSync(join(tenantsDir, slug, f), join(out, "img", basename(f)));
  const icon = join(tenantsDir, slug, t.icon);
  await sharp(icon).resize(192, 192).png().toFile(join(out, "icons/192.png"));
  await sharp(icon).resize(512, 512).png().toFile(join(out, "icons/512.png"));
  await sharp(icon).resize(410, 410).extend({ top: 51, bottom: 51, left: 51, right: 51, background: "#000" }).png().toFile(join(out, "icons/512-maskable.png"));
  await sharp(icon).resize(180, 180).png().toFile(join(out, "icons/apple-touch.png"));
  writeFileSync(join(out, "manifest.webmanifest"), JSON.stringify({
    id: `/s/${slug}/`, name: t.name, short_name: t.name.slice(0, 12), description: t.tagline, lang: "ru",
    start_url: `/s/${slug}/`, scope: `/s/${slug}/`, display: "standalone", orientation: "portrait",
    background_color: "#000000", theme_color: "#000000",
    icons: [
      { src: `/s/${slug}/icons/192.png`, sizes: "192x192", type: "image/png" },
      { src: `/s/${slug}/icons/512.png`, sizes: "512x512", type: "image/png" },
      { src: `/s/${slug}/icons/512-maskable.png`, sizes: "512x512", type: "image/png", purpose: "maskable" },
    ],
  }, null, 2));
  console.log(`✓ ${slug}: фото, иконки и манифест готовы`);
}
