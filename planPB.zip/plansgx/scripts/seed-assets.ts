import { join } from "node:path";
import { placeholderJpg, placeholderPng, tenantsDir } from "./lib.ts";
const d = join(tenantsDir, "detail-lab/photos");
await placeholderJpg(join(d, "hero.jpg"), 1200, 1500, "#0b1a33", "#3f86f5");
await placeholderJpg(join(d, "work-1.jpg"), 800, 560, "#1c2b4a", "#4690FF");
await placeholderJpg(join(d, "work-2.jpg"), 800, 560, "#222831", "#5a6578");
await placeholderJpg(join(d, "work-3.jpg"), 800, 560, "#0d1a33", "#2c5db3");
await placeholderPng(join(d, "icon.png"), 512, "#0b1a33", "#4690FF");
console.log("✓ образцы фото созданы");
