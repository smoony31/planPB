import { readdirSync, existsSync, mkdirSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { pathToFileURL } from "node:url";
import sharp from "sharp";
import { StudioConfig } from "../src/tenant/schema.ts";

export const ROOT = resolve(import.meta.dirname, "..");
export const tenantsDir = join(ROOT, "tenants");
export const listTenants = () =>
  readdirSync(tenantsDir, { withFileTypes: true }).filter((d: { isDirectory(): boolean; name: string }) => d.isDirectory() && !d.name.startsWith("_")).map((d: { name: string }) => d.name);

export async function loadTenant(slug: string) {
  const file = join(tenantsDir, slug, "studio.config.ts");
  if (!existsSync(file)) throw new Error(`Нет файла настроек: tenants/${slug}/studio.config.ts`);
  const mod = await import(pathToFileURL(file).href);
  const parsed = StudioConfig.safeParse(mod.default);
  if (!parsed.success) {
    const msg = parsed.error.issues.map((i) => `  - ${i.path.join(".") || "(корень)"}: ${i.message}`).join("\n");
    throw new Error(`Ошибки в tenants/${slug}/studio.config.ts:\n${msg}`);
  }
  if (parsed.data.slug !== slug) throw new Error(`slug в файле (${parsed.data.slug}) не совпадает с именем папки (${slug})`);
  return parsed.data;
}

/** Временные изображения-заглушки (градиент). Фото владельца всегда важнее: положите свои файлы с теми же именами. */
export async function placeholderPng(path: string, size: number, c1: string, c2: string) {
  mkdirSync(dirname(path), { recursive: true });
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${c1}"/><stop offset="1" stop-color="${c2}"/></linearGradient></defs><rect width="100%" height="100%" fill="url(#g)"/><circle cx="${size / 2}" cy="${size / 2}" r="${size * 0.22}" fill="#fff"/></svg>`;
  await sharp(Buffer.from(svg)).png().toFile(path);
}
export async function placeholderJpg(path: string, w: number, h: number, c1: string, c2: string) {
  mkdirSync(dirname(path), { recursive: true });
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${c1}"/><stop offset="1" stop-color="${c2}"/></linearGradient></defs><rect width="100%" height="100%" fill="url(#g)"/></svg>`;
  await sharp(Buffer.from(svg)).jpeg({ quality: 82 }).toFile(path);
}
