import { cpSync, existsSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { listTenants, loadTenant, placeholderJpg, placeholderPng, tenantsDir } from "./lib.ts";

const [cmd, arg, ...rest] = process.argv.slice(2);
const q = (s: string) => `'${s.replace(/'/g, "''")}'`;
const imgUrl = (slug: string, f?: string) => (f ? q(`/s/${slug}/img/${f.split("/").pop()}`) : "null");

async function check(slug: string) {
  const t = await loadTenant(slug);
  const files = [t.hero, t.icon, t.logo, ...t.works.map((w) => w.file)].filter(Boolean) as string[];
  const missing = files.filter((f) => !existsSync(join(tenantsDir, slug, f)));
  if (missing.length) throw new Error(`tenants/${slug}: нет файлов: ${missing.join(", ")}`);
  console.log(`✓ ${slug}: настройки корректны, файлов: ${files.length}`);
}

async function sql(slug: string, verified: boolean) {
  const t = await loadTenant(slug);
  await check(slug);
  const status = verified ? "verified" : "sample";
  const days = `'{${t.daysOff.join(",")}}'`;
  return `-- ${slug}: ${status}
insert into studios (slug,name,tagline,address,phone,timezone,open_time,close_time,days_off,prep_minutes,cancel_hours,logo_url,hero_url,info_cards,status)
values (${q(t.slug)},${q(t.name)},${q(t.tagline)},${q(t.address)},${q(t.phone)},${q(t.timezone)},${q(t.hours.open)},${q(t.hours.close)},${days},${t.prepMinutes},${t.cancelHours},${imgUrl(slug, t.logo)},${imgUrl(slug, t.hero)},${q(JSON.stringify(t.cards))}::jsonb,${q(status)})
on conflict (slug) do update set name=excluded.name,tagline=excluded.tagline,address=excluded.address,phone=excluded.phone,timezone=excluded.timezone,open_time=excluded.open_time,close_time=excluded.close_time,days_off=excluded.days_off,prep_minutes=excluded.prep_minutes,cancel_hours=excluded.cancel_hours,logo_url=excluded.logo_url,hero_url=excluded.hero_url,info_cards=excluded.info_cards,status=excluded.status;
-- услуги, боксы и фото заменяются только пока у студии нет ни одной записи
do $$ declare s uuid; begin
  select id into s from studios where slug=${q(slug)};
  if not exists (select 1 from bookings where studio_id=s) then
    delete from services where studio_id=s; delete from boxes where studio_id=s; delete from works where studio_id=s;
    ${t.boxes.map((b, i) => `insert into boxes(studio_id,name,position) values (s,${q(b)},${i});`).join("\n    ")}
    ${t.services.map((v, i) => `insert into services(studio_id,name,price,duration_min,position) values (s,${q(v.name)},${v.price},${v.durationMin},${i});`).join("\n    ")}
    ${t.works.map((w, i) => `insert into works(studio_id,photo_url,caption,position) values (s,${imgUrl(slug, w.file)},${q(w.caption)},${i});`).join("\n    ")}
  end if;
end $$;`;
}

async function verifyLink(url: string) {
  const fail = (m: string): never => { throw new Error(`✗ ${m}`); };
  const res = await fetch(url);
  if (!res.ok) fail(`страница отвечает ${res.status}`);
  const html = await res.text();
  const m = html.match(/rel="manifest"[^>]*href="([^"]+)"/) ?? html.match(/href="([^"]+)"[^>]*rel="manifest"/);
  const slug = new URL(url).pathname.split("/")[2];
  const manifestUrl = new URL(m?.[1] ?? `/s/${slug}/manifest.webmanifest`, url).href;
  const mr = await fetch(manifestUrl);
  if (!mr.ok) fail(`манифест недоступен: ${manifestUrl} (${mr.status})`);
  const man = await mr.json();
  for (const ic of man.icons ?? []) { const r = await fetch(new URL(ic.src, url)); if (!r.ok) fail(`иконка недоступна: ${ic.src}`); }
  console.log(`✓ ${url}: страница 200, манифест «${man.name}», иконок: ${man.icons?.length}`);
}

try {
  if (cmd === "new") {
    if (!/^[a-z0-9-]{2,40}$/.test(arg ?? "")) throw new Error("Использование: pnpm studio:new <slug> (a-z, 0-9, дефис)");
    const dst = join(tenantsDir, arg);
    if (existsSync(dst)) throw new Error(`tenants/${arg} уже существует`);
    cpSync(join(tenantsDir, "detail-lab"), dst, { recursive: true });
    const f = join(dst, "studio.config.ts");
    writeFileSync(f, readFileSync(f, "utf8").replace('slug: "detail-lab"', `slug: "${arg}"`));
    await placeholderJpg(join(dst, "photos/hero.jpg"), 1200, 1500, "#10213f", "#2a62bd");
    console.log(`✓ создано tenants/${arg}. Откройте studio.config.ts, замените название, цены, адрес, телефон и фото в photos/, затем: pnpm studio:check ${arg}`);
  } else if (cmd === "check") {
    const slugs = arg && arg !== "--all" ? [arg] : listTenants();
    let bad = 0;
    for (const s of slugs) await check(s).catch((e) => { bad++; console.error("✗", e.message); });
    process.exit(bad ? 1 : 0);
  } else if (cmd === "sql") {
    console.log(await sql(arg, rest.includes("--verified")));
  } else if (cmd === "verify-link") {
    await verifyLink(arg);
  } else {
    console.log("Команды: new <slug> | check [slug|--all] | sql <slug> [--verified] | verify-link <url>");
  }
} catch (e) { console.error((e as Error).message); process.exit(1); }
