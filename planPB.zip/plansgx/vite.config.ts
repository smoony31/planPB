import { defineConfig } from "vitest/config";
import react from "@vitejs/plugin-react";
import { VitePWA } from "vite-plugin-pwa";

export default defineConfig({
  plugins: [
    react(),
    VitePWA({
      registerType: "autoUpdate",
      manifest: false, // манифест у каждой студии свой: public/s/<slug>/manifest.webmanifest
      workbox: {
        navigateFallback: "/index.html",
        navigateFallbackDenylist: [/^\/s\/[^/]+\/(img|icons)\//, /\.[a-z0-9]+$/],
        globPatterns: ["**/*.{js,css,html,svg,woff2}"],
        runtimeCaching: [
          { urlPattern: /\/s\/[^/]+\/(img|icons)\//, handler: "StaleWhileRevalidate", options: { cacheName: "studio-img" } },
          { urlPattern: /\/rest\/v1\/(studios|services|works|boxes)/, handler: "NetworkFirst", options: { cacheName: "studio-data", networkTimeoutSeconds: 4 } },
        ],
      },
    }),
  ],
  test: { include: ["src/**/*.test.ts", "scripts/**/*.test.ts"] },
});
