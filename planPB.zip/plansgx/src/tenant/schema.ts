import { z } from "zod";

const time = z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/, "время в формате ЧЧ:ММ");

export const StudioConfig = z.object({
  slug: z.string().regex(/^[a-z0-9-]{2,40}$/, "slug: a-z, 0-9, дефис, 2–40 символов"),
  name: z.string().min(1).max(80),
  tagline: z.string().max(240),
  address: z.string().min(1).max(200),
  phone: z.string().min(7).max(32),
  timezone: z.string().min(3),
  hours: z.object({ open: time, close: time }).refine((h) => h.open < h.close, "закрытие должно быть позже открытия"),
  daysOff: z.array(z.number().int().min(0).max(6)),
  prepMinutes: z.number().int().min(0).max(600),
  cancelHours: z.number().int().min(0).max(336),
  boxes: z.array(z.string().min(1).max(40)).min(1).max(10),
  services: z.array(z.object({
    name: z.string().min(1).max(80),
    price: z.number().int().min(0),
    durationMin: z.number().int().min(15).max(4320),
  })).min(1).max(30),
  cards: z.array(z.object({ title: z.string().max(60), text: z.string().max(200) })).length(3),
  works: z.array(z.object({ file: z.string(), caption: z.string().max(120) })).max(12),
  hero: z.string(),
  logo: z.string().optional(),
  icon: z.string(),
  accent: z.string().regex(/^#[0-9a-fA-F]{6}$/).default("#4690FF"),
});
export type StudioConfig = z.infer<typeof StudioConfig>;
export type StudioConfigInput = z.input<typeof StudioConfig>;
export const defineStudio = (c: StudioConfigInput) => c;
