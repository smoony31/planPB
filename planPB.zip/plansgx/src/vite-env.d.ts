/// <reference types="vite/client" />
/// <reference types="vite-plugin-pwa/client" />
declare module "liquid-gl" { const liquidGL: (o: Record<string, unknown>) => unknown; export default liquidGL; }
