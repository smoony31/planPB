import { useState } from "react";
import { Link } from "react-router-dom";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { ApiError, callFn } from "../lib/api";
import { useMyBookings, type Service, type Studio, type Work } from "../lib/queries";
import { rub, when } from "../lib/format";

const ST: Record<string, string> = { new: "Новая", ok: "Подтверждена", in: "Машина принята", done: "Готова", cancel: "Отменена" };
type Props = { data: { studio: Studio; services: Service[]; works: Work[] }; base: string };

export function My({ data: { studio: s }, base }: Props) {
  const qc = useQueryClient();
  const q = useMyBookings(s.slug);
  const [msg, setMsg] = useState<Record<string, string>>({});
  const cancel = useMutation({
    mutationFn: (token: string) => callFn("my-booking", { token, action: "cancel" }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["my", s.slug] }),
    onError: (e, token) => setMsg((m) => ({ ...m, [token]: e instanceof ApiError && e.code === "too_late" ? `Отмена возможна не позднее чем за ${s.cancel_hours} ч до визита. Позвоните в студию: ${s.phone}` : "Не удалось отменить. Попробуйте позже." })),
  });
  const list = q.data ?? [];
  return (
    <>
      <h1>Моя запись</h1>
      {q.isLoading && <p className="mu">Загрузка…</p>}
      {!q.isLoading && !list.length && <><p className="mu">Записей на этом устройстве пока нет.</p><Link className="btn" to={base + "book"}>Записаться</Link></>}
      {list.map((b) => (
        <div className="card" key={b.token}>
          <div className="row"><b>{b.service_name}</b><span className={"badge b-" + b.status}>{ST[b.status] ?? b.status}</span></div>
          <div className="mu">{when(b.start_at, s.timezone)}, {rub(b.price)}</div>
          <div className="mu">{s.address}</div>
          {(b.status === "new" || b.status === "ok") && <button className="btn g s" style={{ marginTop: 10 }} disabled={cancel.isPending} onClick={() => { if (confirm("Отменить запись?")) cancel.mutate(b.token); }}>Отменить запись</button>}
          {msg[b.token] && <p className="err" style={{ marginTop: 8 }} role="alert">{msg[b.token]}</p>}
        </div>
      ))}
    </>
  );
}
