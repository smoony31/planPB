import { Link } from "react-router-dom";
import { MapPin } from "@phosphor-icons/react/dist/csr/MapPin";
import { Clock } from "@phosphor-icons/react/dist/csr/Clock";
import { Phone } from "@phosphor-icons/react/dist/csr/Phone";
import { DownloadSimple } from "@phosphor-icons/react/dist/csr/DownloadSimple";
import { useEffect, useState } from "react";
import type { Service, Studio, Work } from "../lib/queries";
import { dur, hours, rub, telHref, workDays } from "../lib/format";

type Props = { data: { studio: Studio; services: Service[]; works: Work[] }; base: string };
type InstallEvent = Event & { prompt: () => Promise<void> };

export function Home({ data: { studio: s, services, works }, base }: Props) {
  const [inst, setInst] = useState<InstallEvent | null>(null);
  useEffect(() => { const h = (e: Event) => { e.preventDefault(); setInst(e as InstallEvent); }; addEventListener("beforeinstallprompt", h); return () => removeEventListener("beforeinstallprompt", h); }, []);
  const ios = /iphone|ipad/i.test(navigator.userAgent) && !matchMedia("(display-mode: standalone)").matches;
  return (
    <>
      <section className="hero">
        {s.hero_url && <img className="bg" src={s.hero_url} alt="" />}
        <p className="mu" style={{ margin: 0 }}>{s.tagline}</p>
        <h1 style={{ margin: "4px 0 0" }}>{s.name}</h1>
        <div className="heroBtns">
          <Link to={base + "book"} className="glassBtn liquidGL">Записаться</Link>
          <a href={telHref(s.phone)} className="glassBtn sec">Позвонить</a>
        </div>
      </section>

      <h2 className="rv">Запись в студию</h2>
      <Link to={base + "book"} className="card row rv" style={{ color: "inherit" }}><span>Выберите услугу, дату и время. Регистрация не нужна.</span><span className="price" style={{ color: "var(--ac)" }}>Далее</span></Link>

      <div className="rv">{s.info_cards.map((c) => <div className="card" key={c.title}><b>{c.title}</b><div className="mu">{c.text}</div></div>)}</div>

      <h2 className="rv">Услуги</h2>
      {services.map((v) => <div className="card row rv" key={v.id}><div>{v.name}<div className="mu">{dur(v.duration_min)}</div></div><span className="price">{rub(v.price)}</span></div>)}

      {works.length > 0 && <><h2 className="rv">Наши работы</h2><div className="photos rv">{works.map((w) => <figure key={w.id}><img src={w.photo_url} alt={w.caption} loading="lazy" /><figcaption>{w.caption}</figcaption></figure>)}</div></>}

      <h2 className="rv">Как нас найти</h2>
      <div className="card rv"><MapPin size={20} /> {s.address}</div>
      <div className="card rv"><Clock size={20} /> {workDays(s.days_off)}, {hours(s.open_time, s.close_time)}</div>
      <a className="card rv" style={{ display: "block", color: "inherit" }} href={telHref(s.phone)}><Phone size={20} /> {s.phone}</a>

      {(inst || ios) && <div className="card rv">
        <b><DownloadSimple size={18} /> Добавить на главный экран</b>
        {inst ? <button className="btn s" style={{ marginTop: 10 }} onClick={() => inst.prompt()}>Установить</button>
          : <div className="mu">Нажмите «Поделиться» в Safari и выберите «На экран Домой».</div>}
      </div>}
    </>
  );
}
