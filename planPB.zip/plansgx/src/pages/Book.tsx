import { useRef, useState } from "react";
import { Link } from "react-router-dom";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { z } from "zod";
import { CalendarPlus } from "@phosphor-icons/react/dist/csr/CalendarPlus";
import { CheckCircle } from "@phosphor-icons/react/dist/csr/CheckCircle";
import { ApiError, callFn } from "../lib/api";
import { addToken, useAvailability, type MyBooking, type Service, type Studio, type Work } from "../lib/queries";
import { dayLabel, dur, rub, when } from "../lib/format";
import { downloadIcs } from "../lib/ics";

const Form = z.object({
  name: z.string().trim().min(1, "Укажите имя").max(80),
  phone: z.string().trim().regex(/^[+\d\s()-]{7,32}$/, "Телефон: только цифры, +, пробелы и скобки").refine((v) => v.replace(/\D/g, "").length >= 7, "Укажите телефон (не меньше 7 цифр)"),
  car: z.string().trim().max(80, "Слишком длинное название"),
});
type Props = { data: { studio: Studio; services: Service[]; works: Work[] }; base: string };
type Done = MyBooking & { client_token: string };

export function Book({ data: { studio: s, services }, base }: Props) {
  const qc = useQueryClient();
  const [svc, setSvc] = useState<Service | null>(null);
  const [date, setDate] = useState<string>("");
  const [time, setTime] = useState<string>("");
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [f, setF] = useState({ name: "", phone: "", car: "" });
  const [err, setErr] = useState("");
  const [done, setDone] = useState<Done | null>(null);
  const key = useRef(crypto.randomUUID());
  const av = useAvailability(s.slug, svc?.id);
  const days = av.data?.days ?? [];
  const day = days.find((d) => d.date === date);

  const m = useMutation({
    mutationFn: () => callFn<{ booking: Done }>("create-booking", { studio: s.slug, service_id: svc!.id, date, time, ...f, idempotency_key: key.current }),
    onSuccess: ({ booking }) => { addToken(s.slug, booking.client_token); key.current = crypto.randomUUID(); setDone(booking); qc.invalidateQueries({ queryKey: ["my", s.slug] }); },
    onError: (e) => {
      const code = e instanceof ApiError ? e.code : "";
      if (code === "slot_taken" || code === "slot_unavailable") { setErr("Это время только что заняли. Выберите другое."); setTime(""); setStep(2); key.current = crypto.randomUUID(); av.refetch(); }
      else if (code === "too_many_bookings") setErr("Слишком много активных записей на этот телефон. Позвоните в студию.");
      else setErr("Не удалось записаться. Проверьте связь и попробуйте ещё раз.");
    },
  });

  if (done) return (
    <div className="card c" style={{ marginTop: 24 }}>
      <div className="tick"><CheckCircle size={36} weight="fill" /></div>
      <h2 style={{ marginTop: 0 }}>Вы записаны</h2>
      <p>{done.service_name}<br />{when(done.start_at, s.timezone)}</p>
      <p className="mu">{s.address}. Студия подтвердит запись по телефону.</p>
      <button className="btn g" style={{ marginBottom: 10 }} onClick={() => downloadIcs({ id: done.id, title: `${s.name}: ${done.service_name}`, start: done.start_at, end: done.end_at, place: s.address })}><CalendarPlus size={18} /> Напомнить за сутки (в календарь)</button>
      <Link className="btn" to={base + "my"}>Моя запись</Link>
    </div>
  );

  const submit = () => {
    const p = Form.safeParse(f);
    if (!p.success) return setErr(p.error.issues[0].message);
    setErr(""); m.mutate();
  };

  return (
    <>
      <h1>Запись в студию</h1>
      <p className="mu">Шаг {step} из 3</p>
      {step === 1 && services.map((v) => (
        <button key={v.id} className="card row sel" onClick={() => { setSvc(v); setDate(""); setTime(""); setStep(2); key.current = crypto.randomUUID(); }}>
          <div>{v.name}<div className="mu">{dur(v.duration_min)}</div></div><span className="price">{rub(v.price)}</span>
        </button>
      ))}
      {step === 2 && svc && <>
        <div className="card"><b>{svc.name}</b> <span className="mu">{rub(svc.price)}, {dur(svc.duration_min)}</span></div>
        {err && <p className="err" role="alert">{err}</p>}
        {av.isLoading && <p className="mu">Считаем свободное время…</p>}
        {av.isError && <p className="err">Не удалось загрузить время. Попробуйте ещё раз.</p>}
        {days.length > 0 && <>
          <h2>Дата</h2>
          <div className="chips">{days.map((d) => (
            <button key={d.date} className={"chip" + (d.date === date ? " on" : "")} disabled={d.closed} style={d.closed ? { opacity: .35 } : undefined} onClick={() => { setDate(d.date); setTime(""); setErr(""); }}>
              {d.date.slice(8)}<small>{dayLabel(d.date).split(",")[0]}</small>
            </button>))}</div>
          {day && <><h2>Время</h2>
            {day.slots.every((x) => !x.free) && <p className="mu">На этот день свободного времени нет. Выберите другую дату.</p>}
            <div className="grid">{day.slots.map((x) => <button key={x.time} className={"slot" + (x.time === time ? " on" : "")} disabled={!x.free} aria-label={x.free ? x.time : `${x.time}, занято`} onClick={() => { setTime(x.time); setErr(""); }}>{x.time}</button>)}</div>
            <p className="mu" style={{ marginTop: 8, fontSize: 13 }}>Зачёркнутое время занято.</p></>}
        </>}
        <div className="btns"><button className="btn g" onClick={() => setStep(1)}>Назад</button><button className="btn" disabled={!time} onClick={() => setStep(3)}>Далее</button></div>
      </>}
      {step === 3 && svc && <>
        <div className="card"><b>{svc.name}</b><div className="mu">{date} в {time}, {rub(svc.price)}</div></div>
        <h2>Ваши данные</h2>
        <input placeholder="Имя" autoComplete="name" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
        <input placeholder="Телефон" type="tel" autoComplete="tel" inputMode="tel" value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} />
        <input placeholder="Марка и модель авто" value={f.car} onChange={(e) => setF({ ...f, car: e.target.value })} />
        {err && <p className="err" role="alert">{err}</p>}
        <div className="btns"><button className="btn g" onClick={() => { setErr(""); setStep(2); }}>Назад</button><button className="btn" disabled={m.isPending} onClick={submit}>{m.isPending ? "Записываем…" : "Записаться"}</button></div>
      </>}
    </>
  );
}
