import { useEffect } from "react";
import { NavLink, Route, Routes, useParams } from "react-router-dom";
import { House } from "@phosphor-icons/react/dist/csr/House";
import { Wrench } from "@phosphor-icons/react/dist/csr/Wrench";
import { Receipt } from "@phosphor-icons/react/dist/csr/Receipt";
import { useStudio } from "../lib/queries";
import { useGlass } from "../lib/useGlass";
import { useReveal } from "../lib/useReveal";
import { Home } from "./Home";
import { Book } from "./Book";
import { My } from "./My";

function setHead(slug: string, name: string) {
  document.title = name;
  const set = (rel: string, href: string) => { let l = document.querySelector<HTMLLinkElement>(`link[rel="${rel}"]`); if (!l) { l = document.createElement("link"); l.rel = rel; document.head.appendChild(l); } l.href = href; };
  set("manifest", `/s/${slug}/manifest.webmanifest`);
  set("apple-touch-icon", `/s/${slug}/icons/apple-touch.png`);
  set("icon", `/s/${slug}/icons/192.png`);
}

export function StudioApp() {
  const { slug = "" } = useParams();
  const q = useStudio(slug);
  const d = q.data;
  useEffect(() => { if (d) setHead(slug, d.studio.name); }, [slug, d]);
  useReveal(d);
  useGlass(!!d, slug);

  if (q.isLoading) return <div className="page"><p className="mu" style={{ paddingTop: 40 }}>Загрузка…</p></div>;
  if (q.isError) return <div className="page"><h1>Нет связи</h1><p className="mu">Не удалось загрузить данные студии. Проверьте интернет и обновите страницу.</p></div>;
  if (!d) return <div className="page"><h1>Студия не найдена</h1><p className="mu">Проверьте ссылку.</p></div>;

  const base = `/s/${slug}/`;
  return (
    <>
      <main className="page">
        {d.studio.status === "sample" && <div className="sample">Образец: студия пока не проверена владельцем.</div>}
        <Routes>
          <Route index element={<Home data={d} base={base} />} />
          <Route path="book" element={<Book data={d} base={base} />} />
          <Route path="my" element={<My data={d} base={base} />} />
        </Routes>
      </main>
      <nav className="dock liquidGL" aria-label="Основная навигация">
        <NavLink to={base} end className={({ isActive }) => (isActive ? "on" : "")}><House size={22} weight="duotone" />Главная</NavLink>
        <NavLink to={base + "book"} className={({ isActive }) => (isActive ? "on" : "")}><Wrench size={22} weight="duotone" />Услуги</NavLink>
        <NavLink to={base + "my"} className={({ isActive }) => (isActive ? "on" : "")}><Receipt size={22} weight="duotone" />Моя запись</NavLink>
      </nav>
    </>
  );
}
