import { useEffect } from "react";
/** Плавное появление при прокрутке. При «уменьшении движения» в системе элементы видны сразу (см. css). */
export function useReveal(dep: unknown) {
  useEffect(() => {
    if (matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const io = new IntersectionObserver((es) => es.forEach((e) => { if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target); } }), { threshold: 0.12 });
    document.querySelectorAll(".rv:not(.in)").forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, [dep]);
}
