import { useEffect } from "react";

/** Настоящее стекло (WebGPU/WebGL) для нижней панели и кнопки на главном фото. Библиотека (≈300 КБ) грузится после первой отрисовки;
 *  без GPU или при «уменьшении движения» остаётся CSS-стекло (backdrop-filter). */
export function useGlass(ready: boolean, dep: unknown) {
  useEffect(() => {
    if (!ready || matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    let lens: { destroy?: () => void } | undefined;
    let dead = false;
    const t = setTimeout(async () => {
      try {
        const { default: liquidGL } = await import("liquid-gl");
        if (dead) return;
        lens = liquidGL({ target: ".liquidGL", snapshot: "body", resolution: 1.5, refraction: 0.012, bevelDepth: 0.08, bevelWidth: 0.15, frost: 2, shadow: true, specular: false, tilt: false, tint: "rgba(70,144,255,0.12)" }) as typeof lens;
      } catch { /* остаётся CSS-стекло */ }
    }, 600);
    return () => { dead = true; clearTimeout(t); try { lens?.destroy?.(); } catch { /* ничего */ } };
  }, [ready, dep]);
}
