import { formatInTimeZone } from "date-fns-tz";
import { ru } from "date-fns/locale";

export const rub = (n: number) => n.toLocaleString("ru-RU") + " ₽";
export const when = (iso: string, tz: string) => formatInTimeZone(new Date(iso), tz, "d MMMM, EEEEEE, HH:mm", { locale: ru });
export const dayLabel = (d: string) => new Date(d + "T12:00:00Z").toLocaleDateString("ru", { weekday: "short", day: "numeric", timeZone: "UTC" });
export const dur = (min: number) => (min >= 480 ? `${Math.round((min / 60) * 10) / 10} ч` : min >= 60 ? `${Math.floor(min / 60)} ч${min % 60 ? " " + (min % 60) + " мин" : ""}` : `${min} мин`);
export const hours = (open: string, close: string) => `${open.slice(0, 5)}–${close.slice(0, 5)}`;
const WD = ["Вс", "Пн", "Вт", "Ср", "Чт", "Пт", "Сб"];
export const workDays = (off: number[]) => { const on = [1, 2, 3, 4, 5, 6, 0].filter((d) => !off.includes(d)); return on.length === 7 ? "Ежедневно" : on.map((d) => WD[d]).join(", "); };
export const telHref = (p: string) => "tel:" + p.replace(/[^+\d]/g, "");
