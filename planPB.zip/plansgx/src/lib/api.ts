import { createClient } from "@supabase/supabase-js";

const URL_ = import.meta.env.VITE_SUPABASE_URL as string;
const KEY = import.meta.env.VITE_SUPABASE_ANON_KEY as string; // публичный ключ; секретных ключей в коде сайта нет
export const sb = createClient(URL_, KEY);

export class ApiError extends Error {
  constructor(public code: string, public status: number, public body: unknown) { super(code); }
}

export async function callFn<T>(name: string, body: unknown): Promise<T> {
  const r = await fetch(`${URL_}/functions/v1/${name}`, {
    method: "POST",
    headers: { "Content-Type": "application/json", apikey: KEY, Authorization: `Bearer ${KEY}` },
    body: JSON.stringify(body),
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new ApiError((j as { error?: string }).error ?? "error", r.status, j);
  return j as T;
}
