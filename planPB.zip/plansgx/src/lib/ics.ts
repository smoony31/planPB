const z = (d: Date) => d.toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, "");
/** Файл календаря с напоминанием за сутки: работает там, где уведомления сайта недоступны. */
export function downloadIcs(o: { id: string; title: string; start: string; end: string; place: string }) {
  const lines = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//plan sgx//RU", "BEGIN:VEVENT", `UID:${o.id}@plansgx`, `DTSTAMP:${z(new Date())}`,
    `DTSTART:${z(new Date(o.start))}`, `DTEND:${z(new Date(o.end))}`, `SUMMARY:${o.title}`, `LOCATION:${o.place}`,
    "BEGIN:VALARM", "TRIGGER:-P1D", "ACTION:DISPLAY", "DESCRIPTION:Запись завтра", "END:VALARM", "END:VEVENT", "END:VCALENDAR"];
  const url = URL.createObjectURL(new Blob([lines.join("\r\n")], { type: "text/calendar" }));
  const a = Object.assign(document.createElement("a"), { href: url, download: "zapis.ics" });
  document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 1000);
}
