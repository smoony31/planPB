import { useQuery } from "@tanstack/react-query";
import { callFn, sb } from "./api";

export type Studio = {
  id: string; slug: string; name: string; tagline: string; address: string; phone: string; timezone: string;
  open_time: string; close_time: string; days_off: number[]; prep_minutes: number; cancel_hours: number;
  logo_url: string | null; hero_url: string | null; info_cards: { title: string; text: string }[]; status: "sample" | "verified";
};
export type Service = { id: string; name: string; price: number; duration_min: number };
export type Work = { id: string; photo_url: string; caption: string };

const STUDIO_COLS = "id,slug,name,tagline,address,phone,timezone,open_time,close_time,days_off,prep_minutes,cancel_hours,logo_url,hero_url,info_cards,status";

export function useStudio(slug: string) {
  return useQuery({
    queryKey: ["studio", slug],
    queryFn: async () => {
      const { data: studio, error } = await sb.from("studios").select(STUDIO_COLS).eq("slug", slug).maybeSingle();
      if (error) throw error;
      if (!studio) return null;
      const [services, works] = await Promise.all([
        sb.from("services").select("id,name,price,duration_min").eq("studio_id", studio.id).order("position"),
        sb.from("works").select("id,photo_url,caption").eq("studio_id", studio.id).order("position"),
      ]);
      return { studio: studio as Studio, services: (services.data ?? []) as Service[], works: (works.data ?? []) as Work[] };
    },
  });
}

export type Day = { date: string; closed: boolean; slots: { time: string; free: boolean }[] };
export function useAvailability(slug: string, serviceId?: string) {
  return useQuery({
    queryKey: ["availability", slug, serviceId],
    enabled: !!serviceId,
    refetchInterval: 30_000,
    queryFn: () => callFn<{ days: Day[]; service: Service & { duration_min: number } }>("availability", { studio: slug, service_id: serviceId, days: 14 }),
  });
}

export type MyBooking = {
  id: string; service_name: string; price: number; start_at: string; end_at: string; status: string;
  studio: { name: string; address: string; phone: string; timezone: string; cancel_hours: number };
};
export const tokensKey = (slug: string) => `sgx:${slug}:tokens`;
export const getTokens = (slug: string): string[] => { try { return JSON.parse(localStorage.getItem(tokensKey(slug)) ?? "[]"); } catch { return []; } };
export const addToken = (slug: string, t: string) => { try { localStorage.setItem(tokensKey(slug), JSON.stringify([t, ...getTokens(slug)].slice(0, 20))); } catch { /* память недоступна */ } };

export function useMyBookings(slug: string) {
  return useQuery({
    queryKey: ["my", slug],
    queryFn: async () => {
      const res = await Promise.all(getTokens(slug).map((token) => callFn<{ booking: MyBooking }>("my-booking", { token, action: "get" }).then((r) => ({ token, ...r.booking })).catch(() => null)));
      return res.filter(Boolean) as (MyBooking & { token: string })[];
    },
  });
}
